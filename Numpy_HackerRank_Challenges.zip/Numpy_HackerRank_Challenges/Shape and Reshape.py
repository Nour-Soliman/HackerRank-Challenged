import numpy
inp=list(map(int,input().strip().split(' ')))
print (numpy.reshape(inp,(3,3)))