import numpy
li=list(map(int,input().split(' ')))
print(numpy.zeros(li, dtype=int))
print(numpy.ones(li, dtype=int))